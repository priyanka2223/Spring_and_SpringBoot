package com.telusko.demo_DI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoDiApplicationTests {

	@Test
	void contextLoads() {
	}

}
